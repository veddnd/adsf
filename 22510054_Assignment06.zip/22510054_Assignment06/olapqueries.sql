USE CustomerWarehouseDW;

-- 1. Find all the stores along with city, state, phone, description, size, weight and  
-- unit  price that hold a particular item of stock. 

SELECT S.Store_id, S.City_name, S.State, S.Phone, 
       I.Description, I.Size, I.Weight, I.Unit_price
FROM CustomerWarehouseDW.FactSales F
JOIN CustomerWarehouseDW.DimStore S ON F.Store_id = S.Store_id
JOIN CustomerWarehouseDW.DimItem I ON F.Item_id = I.Item_id
WHERE I.Item_id = 1;  -- Replace with required Item_id


-- 2. Find all the orders along with customer name and order date that can be  
-- fulfilled by a given store.
SELECT O.Order_no, O.Order_date, C.Customer_name
FROM CustomerWarehouseDW.FactSales O
JOIN CustomerWarehouseDW.DimCustomer C ON O.Customer_id = C.Customer_id
WHERE O.Store_id = 1;  -- Replace with Store_id
 
-- 3. Find all stores along with city name and phone that hold items ordered by  
-- given customer. 
SELECT DISTINCT S.Store_id, S.City_name, S.Phone
FROM CustomerWarehouseDW.FactSales O
JOIN CustomerWarehouseDW.DimStore S ON O.Store_id = S.Store_id
WHERE O.Customer_id = 1;  -- Replace with Customer_id

-- 4. Find the headquarter address along with city and state of all stores that hold  
-- stocks of an item above a particular level. 
SELECT S.Headquarter, S.HQ_Address, S.HQ_State
FROM CustomerWarehouseDW.FactSales F
JOIN CustomerWarehouseDW.DimStore S ON F.Store_id = S.Store_id
WHERE F.Stock_available > 5;  -- Replace with required stock threshold

-- 5. For each customer order, show the items ordered along with description, store  
-- id and city name and the stores that hold the items. 
SELECT O.Order_no, O.Order_date, C.Customer_name, 
       I.Description, S.Store_id, S.City_name
FROM CustomerWarehouseDW.FactSales O
JOIN CustomerWarehouseDW.DimCustomer C ON O.Customer_id = C.Customer_id
JOIN CustomerWarehouseDW.DimItem I ON O.Item_id = I.Item_id
JOIN CustomerWarehouseDW.DimStore S ON O.Store_id = S.Store_id;

-- 6. Find the city and the state in which a given customer lives. 
SELECT City_name, State 
FROM CustomerWarehouseDW.DimCustomer 
WHERE Customer_id = 1;  -- Replace with Customer_id

-- 7. Find the stock level of a particular item in all stores in a particular city. 
SELECT S.Store_id, S.City_name, F.Stock_available
FROM CustomerWarehouseDW.FactSales F
JOIN CustomerWarehouseDW.DimStore S ON F.Store_id = S.Store_id
WHERE F.Item_id = 1 AND S.City_name = 'New York';  -- Replace with Item_id and City_name

-- 8. Find the items, quantity ordered, customer, store and city of an order. 
SELECT O.Order_no, I.Description, O.Quantity_ordered, 
       C.Customer_name, S.Store_id, S.City_name
FROM CustomerWarehouseDW.FactSales O
JOIN CustomerWarehouseDW.DimItem I ON O.Item_id = I.Item_id
JOIN CustomerWarehouseDW.DimCustomer C ON O.Customer_id = C.Customer_id
JOIN CustomerWarehouseDW.DimStore S ON O.Store_id = S.Store_id
WHERE O.Order_no = 1001;  -- Replace with Order Number

-- 9. Find the walk in customers, mail order customers and dual customers (both  
-- walk-in and mail order). 
SELECT Customer_name, Customer_type 
FROM CustomerWarehouseDW.DimCustomer
WHERE Customer_type IN ('Walk-in', 'Mail-order', 'Both');
